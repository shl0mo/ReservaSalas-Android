package com.example.reservasalas;

import java.sql.Connection;

public class Globais {
    static String id;
    static String usuario;
    static DB db;
}
